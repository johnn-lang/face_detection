pass_word='hsqw ytet ymro bnmq'
import smtplib
import cv2
from email.message import EmailMessage
def sent_email(img):
    EMAIL = "animal.com1@gmail.com"
    # app password

    msg = EmailMessage()
    msg["From"] = EMAIL
    msg["To"] = "lobsternhi@gmail.com"
    msg["Subject"] = "Test email from Python"
    msg.set_content("Xin chào 👋\nĐây là email gửi từ Python 🐍 . \n Phòng lab của bạn đã bị đột nhập")
    _, buffer = cv2.imencode(".png", img)

    msg.add_alternative("""
    <html>
    <body>
        <h3>Kết quả model:</h3>
        <img src="cid:img1">
    </body>
    </html>
    """, subtype="html")

    msg.get_payload()[1].add_related(
        buffer.tobytes(),
        maintype="image",
        subtype="png",
        cid="img1"
    )
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
        smtp.login(EMAIL, pass_word)
        smtp.send_message(msg)

