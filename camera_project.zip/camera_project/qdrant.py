from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue
import uuid
import cv2
import numpy as np
class Qdrant():
    def __init__(self):
        
        self.qdrant_client = QdrantClient(
            url="https://95851596-c453-43d5-800f-cf774e83e2cd.us-east4-0.gcp.cloud.qdrant.io:6333", 
            api_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.A2WqgYETFGuUG4KGJAOSVb0yoNfbUh-QRDgfiayAMVw",
        )


    def str_to_uuid(self,s):
        return uuid.uuid5(uuid.NAMESPACE_DNS, s)
    def insert(self,name,vector):
        group_id = name.split("_")[0]
        self.qdrant_client.upsert(
            collection_name="my_vector",
            points=[
                {
                    "id": self.str_to_uuid(name),
                    "vector": vector,
                "payload": {
                    "status": "Normal",
                    "group_id": group_id,
                }
                }
            ],
        )
    def delete(self,name):
        point_id=self.str_to_uuid(name)
        self.qdrant_client.delete(
            collection_name="my_vector",
            points_selector=[point_id])
    def delete_by_group(self, group_id: str):
        f = Filter(
            must=[
                FieldCondition(
                    key="group_id",
                    match=MatchValue(value=group_id)
                )
            ]
        )

        self.qdrant_client.delete(
            collection_name="my_vector",
            points_selector=f
        )
    def ban(self,group_id):
        f = Filter(
            must=[
                FieldCondition(
                    key="group_id",
                    match=MatchValue(value=group_id)
                )
            ]
        )
        self.qdrant_client.set_payload(
        collection_name="my_vector",
        payload={
            "status": "Disabled"   
        },
        points=f)
    def extract_all(self):
        all_points = []
        offset = None

        while True:
            points, offset = self.qdrant_client.scroll(
                collection_name="my_vector",
                limit=256,              
                offset=offset,
                with_vectors=True,   
                with_payload=True
            )

            all_points.extend(points)

            if offset is None:
                break
        return all_points

    def unban(self,group_id):
        f = Filter(
            must=[
                FieldCondition(
                    key="group_id",
                    match=MatchValue(value=group_id)
                )
            ]
        )
        self.qdrant_client.set_payload(
        collection_name="my_vector",
        payload={
            "status": "Normal"   
        },
        points=f)

    def retrieve(self, name):
        point_id = self.str_to_uuid(name)

        points = self.qdrant_client.retrieve(
            collection_name="my_vector",
            ids=[point_id],
            with_vectors=True,
            with_payload=True 
        )

        return points[0] if points else None




    #q.delete('son_tung')


