import torch
from facenet_pytorch import InceptionResnetV1
import os
import pickle
import torch.nn.functional as F
import face_recognition
import cv2
import numpy as np
from torchvision import transforms
from PIL import Image
from ultralytics import YOLO
import cv2
import pickle
import torch
import torch.nn.functional as F
from PIL import Image
from torchvision import transforms
from facenet_pytorch import InceptionResnetV1
from ultralytics import YOLO
from qdrant import Qdrant


class YoloDetector():
    def __init__(self, device=None):
        # Set device
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        yolo_path=os.path.join(BASE_DIR,'best.pt')
        # Load database
        self.qdrant1=Qdrant()
        self.db = self.qdrant1.extract_all()

 

        self.no_face=False
        
        # Face embedding model
        self.embed_model = InceptionResnetV1(pretrained='vggface2').eval().to(self.device)
        
        # Transform for face images
        self.transform = transforms.Compose([
            transforms.Resize((160, 160)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5],
                                 std=[0.5, 0.5, 0.5])
        ])
        
        # Detection model
        self.model = YOLO(yolo_path)
        self.id = None

    def detect(self, frame,register=False):
        self.frame=frame.copy()
        self.id=None
        self.no_face=False
        try:
            # Convert frame to RGB (PIL can handle this)
            frame_rgb = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            
            # Run detection
            results = self.model(frame_rgb)
            r = results[0]
            scores = r.boxes.conf      # confidence
            boxes = r.boxes.xyxy  # tensor [N, 4]
            
            if boxes is None or len(boxes) == 0:
                self.no_face=True
                return  False 
            for box, score,  in zip(boxes, scores):
                x1, y1, x2, y2 = map(int, box.tolist())

                label = f"{score:.2f}"

                # Vẽ rectangle
                cv2.rectangle(frame, (x1, y1), (x2, y2),
                            (0, 255, 0), 2)

                # Vẽ label
                cv2.putText(frame, label,
                            (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (0, 255, 0), 2)
                self.frame=frame.copy()
            for box in boxes:
                # Convert box to ints
                xmin, ymin, xmax, ymax = map(int, box)
                
                # Crop face directly from PIL frame
                face = frame_rgb.crop((xmin, ymin, xmax, ymax))
                
                # Preprocess and send to device
                face_tensor = self.transform(face).unsqueeze(0).to(self.device)
                
                # Get embedding
                with torch.no_grad():
                    emb_target = self.embed_model(face_tensor)
                if register:
                    self.embedding=emb_target
                    return True
                
                # Compare with database
                max_sim = 0
                best_id = None
                for point in self.db:
                    if point.payload["status"]=="Disabled":
                        continue
                    embed_tensor = torch.tensor(point.vector, device=self.device).unsqueeze(0)
                    sim = F.cosine_similarity(emb_target, embed_tensor)
                    id=point.payload["group_id"]
                    if sim.item() > max_sim:
                        max_sim = sim.item()
                        best_id = id
                
                
                # Threshold check
                if max_sim >= 0.6:
                    self.id = best_id
                    print('This is', self.id)
                    print('Conf', max_sim)
                    return True  # recognized

            

            return False  # no match found

        except Exception as e:
            print("Detection error:", e)
            return False

class Detector():
    def __init__(self):
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        with open("face_pickle.pkl", "rb") as f:
            self.db = pickle.load(f)
        self.model = InceptionResnetV1(pretrained='vggface2').eval()
        self.transform= transforms.Compose([

    transforms.ToTensor(),  # PIL → torch.Tensor [3, H, W]
    transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std =[0.229, 0.224, 0.225]
    )
])
    def detect(self, frame):
        try:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(frame)
            self.id=None
            face_in_frame= []

            for (top, right, bottom, left) in face_locations:
                face_img = frame[top:bottom, left:right]
                face_in_frame.append(face_img)
            


            face_pil = Image.fromarray(face_in_frame[0])
    

            face_resized = face_pil.resize((80, 80), Image.BILINEAR)

            face_resized = np.array(face_resized)




            max_value=0
            emb_target=self.model(self.transform(face_resized).unsqueeze(0))
            for id,embed in self.db.items():
                sim = F.cosine_similarity(emb_target,torch.tensor(embed))
                if max_value<sim.item():
                    max_value=sim.item()
                    self.id=id
            if max_value<0.5:
                return False
            print('This is',self.id)
            return True
        except:
            return False
  

