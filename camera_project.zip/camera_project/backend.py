from flask import Flask, render_template, Response
import cv2
import numpy as np
from Detect_class import YoloDetector
from qdrant import Qdrant

app = Flask(__name__)
qdrantt=Qdrant()
camera = cv2.VideoCapture(0)
detector = YoloDetector()

old_frame = None
count = 0
global is_adding_user 
is_adding_user = False

def gen_frames():
    global old_frame, count, is_adding_user, current_user_id

    if not camera.isOpened():
        raise RuntimeError("Không mở được camera")

    while True:
        ret, frame = camera.read()
        if not ret:
            break

        if count % 30 == 0 and old_frame is not None:
            mse = np.mean(
                (frame.astype("float") - old_frame.astype("float")) ** 2
            )
           
       
            if mse > 100 or (mse>20 and is_adding_user):
                frame = detector.detect(frame, register=is_adding_user)
              
                if detector.no_face:
                    print("❌ No face")
                else:
                    if is_adding_user:
                        embedding=detector.embedding[0]
                        print(embedding.shape)
                        name=str(current_user_id) + "_" + str(count)
                        qdrantt.insert(name,embedding)
                        detector.db=qdrantt.extract_all()
                        print('Adding')


                    if detector.id is not None:
                        print("✅ Welcome:", detector.id)
                        frame = detector.frame   
                    else:
                        print("❌ No match")

        old_frame = frame
        count += 1

        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        yield (
            b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' +
            frame_bytes +
            b'\r\n'
        )


@app.route('/')
def index():
    return render_template('ui.html')


@app.route('/video_feed')
def video_feed():
    return Response(
        gen_frames(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )
from flask import request, jsonify

@app.route("/start_add_user", methods=["POST"])
def start_add_user():
    global is_adding_user, current_user_id

    data = request.json
    user_id = data.get("user_id")

    if not user_id:
        return jsonify({"error": "Missing user_id"}), 400
    
    is_adding_user = True
    current_user_id = user_id

    return jsonify({"message": "📸 Đang quay để đăng ký user, vui lòng nhìn thẳng camera"})
@app.route("/stop_add_user", methods=["POST"])
def stop_add_user():
    global is_adding_user, current_user_id

    is_adding_user = False
    finished_user = current_user_id
    current_user_id = None

    return jsonify({
        "message": "User added successfully",
        "user_id": finished_user
    })


@app.route("/remove_user", methods=["POST"])
def remove_user():
    data = request.json
    user_id = data.get("user_id")
    if not user_id:
        return jsonify({"message": "Missing user_id"}), 400
    
    qdrantt.delete_by_group(user_id)
    detector.db=qdrantt.extract_all()
    return jsonify({
        "message": f"User {user_id} removed successfully",
    })

@app.route("/ban_user", methods=["POST"])
def ban_user():
    data = request.json
    user_id = data.get("user_id")
    if not user_id:
        return jsonify({"message": "Missing user_id"}), 400
    qdrantt.ban(user_id)
    detector.db=qdrantt.extract_all()
    return jsonify({
        "message": f"User {user_id} banned successfully",
    })
@app.route("/unban_user", methods=["POST"])
def unban_user():
    data = request.json
    user_id = data.get("user_id")
    if not user_id:
        return jsonify({"message": "Missing user_id"}), 400
    qdrantt.unban(user_id)
    detector.db=qdrantt.extract_all()
    return jsonify({
        "message": f"User {user_id} is granted access",

    })
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True, use_reloader=False)
